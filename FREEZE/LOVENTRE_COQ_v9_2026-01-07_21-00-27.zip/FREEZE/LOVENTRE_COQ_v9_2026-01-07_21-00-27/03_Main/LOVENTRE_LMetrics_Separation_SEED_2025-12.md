# LOVENTRE – Mini Teorema di Loventre (LMetrics + Policy)
## Seed di stato – dicembre 2025

Questo file fotografa lo stato dell’asse **LMetrics + Policy + SAFE + Accessibile**
a dicembre 2025, lato Coq, e il collegamento con il motore Python.

---

## 0. Root e compilazione di riferimento

Root Coq:

```bash
cd "/Users/vincenzoloventre/Library/Mobile Documents/com~apple~CloudDocs/PROGETTO TEOREMA/Loventre_Coq_Modules/Loventre_Coq_Clean"

