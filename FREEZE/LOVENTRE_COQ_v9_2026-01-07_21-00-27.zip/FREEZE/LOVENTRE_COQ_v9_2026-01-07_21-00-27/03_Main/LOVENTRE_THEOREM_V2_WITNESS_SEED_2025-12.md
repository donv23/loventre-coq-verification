# LOVENTRE_THEOREM_V2_WITNESS_SEED – dicembre 2025

_Asse: LMetrics + Policy + SAFE + Profili di complessità + Witness JSON_

Root Coq:
`/Users/vincenzoloventre/Library/Mobile Documents/com~apple~CloudDocs/PROGETTO TEOREMA/Loventre_Coq_Modules/Loventre_Coq_Clean`

Root Python (motore):
`/Users/vincenzoloventre/Library/Mobile Documents/com~apple~CloudDocs/ALGORITIMIA/LOVENTRE_ENGINE_CLEAN/loventre_engine_clean_seed`

---

## 1. Test operativo dei profili di complessità (Python)

Script usato:

```bash
cd "/Users/vincenzoloventre/Library/Mobile Documents/com~apple~CloudDocs/ALGORITIMIA/LOVENTRE_ENGINE_CLEAN/loventre_engine_clean_seed"
python3 loventre_complexity_profile_view.py

